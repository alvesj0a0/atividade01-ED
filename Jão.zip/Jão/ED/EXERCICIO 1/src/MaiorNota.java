import java.util.Scanner;

public class MaiorNota {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] notas = new int[10];
        int maior = Integer.MIN_VALUE;
        int menor = Integer.MAX_VALUE;

        System.out.println("Digite 10 Notas:");
        for (int i = 0; i < notas.length; i++) {
            System.out.print("A nota Do Aluno " + (i + 1) + "é : ");
            notas[i] = sc.nextInt();

            if (notas[i] > maior) {
                maior = notas[i];
            }
            if (notas[i] < menor) {
                menor = notas[i];
            }
        }

        System.out.println("A maior nota é: " + maior);
        sc.close();
    }
}
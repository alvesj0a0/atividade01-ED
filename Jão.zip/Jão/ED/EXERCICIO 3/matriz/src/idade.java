public class idade {
    public static void main(String[] args) {
        int[] idades = { 20, 55, 65, 33, 80, 32, 9, 18, 25, 77 };

        System.out.println("As Idades maiores que 18:");
        for (int idade : idades) {
            if (idade > 18) {
                System.out.println(idade);
            }
        }
    }
}
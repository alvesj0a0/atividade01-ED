import java.util.Scanner;

public class NumerosPAR {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] vetor = new int[10];

        System.out.println("Escreva 10 valores inteiros ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("Numero " + (i + 1) + ": ");
            vetor[i] = sc.nextInt();
        }

        System.out.println("Valores pares:");
        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] % 2 == 0) {
                System.out.println("Os numeros pares :" + vetor[i]);
            }
        }

        sc.close();
    }
}
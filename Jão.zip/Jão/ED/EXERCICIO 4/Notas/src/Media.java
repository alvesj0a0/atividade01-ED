public class Media {
    public static void main(String[] args) {

        double[] notas = { 8.5, 9.0, 5.5, 8.8 };

        double soma = 0.0;
        for (double num : notas) {
            soma += num;
        }
        double media = soma / notas.length;

        System.out.printf("Notas: ");
        for (double num : notas) {
            System.out.print(num + " ");
        }
        System.out.println();
        System.out.printf("Média é : %.2f%n", media);
    }
}